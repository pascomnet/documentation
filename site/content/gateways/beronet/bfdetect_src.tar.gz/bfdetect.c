/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: bfdetect.c
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>

#include "beronet_device.h"
#include "beronet_network.h"
#include "beronet_usage.h"

static int sayGoodBye (const int returnValue) {

	printf("\nGoodbye!\n\n");

	return(returnValue);
}

static void get_all (void) {
	int input;

	while (1) {
		input = getchar();
		if (input == EOF || input == '\n')
			break;
	}
}

static int get_int (char *msg) {
	int input;

	do {
		printf("%s", msg);
		fflush(stdout);
		if (scanf("%u", &input) == 1) {
			get_all();
			return input;
		}
		while (1) {
			input = getchar();
			if (input == EOF || input == '\n')
				break;
		}
	} while (1);
}

static char get_char (char *msg, char *good) {

	int input;

	do {
		printf("%s", msg);
		fflush(stdout);
		while (1) {
			input = getchar();
			if (input == EOF || input == '\n')
				break;
			if (strchr(good, input)) {
				get_all();
				return input;
			}
		}
	} while (1);
}

static uint8_t verifyMacAddress (char *str_m) {

	int	i	= 0,
		a[6];

	if (sscanf(str_m, "%x:%x:%x:%x:%x:%x", &a[0], &a[1], &a[2], &a[3], &a[4], &a[5]) != 6) {
		return(0);
	}

	for (i = 0; i < 6; i++) {
		if ((a[i] < 0x00) || (a[i] > 0xff)) {
			return(0);
		}
	}

	return(1);
}

static uint8_t verifyIpAddress (const char *ipAddress) {

	int	i	= 0,
		a[4]	= {-1, -1, -1, -1};

	if (sscanf(ipAddress, "%d.%d.%d.%d", &a[0], &a[1], &a[2], &a[3]) != 4) {
		return(0);
	}

	for (i = 0; i < 4; i++) {
		if ((a[i] < 0)  || (a[i] > 0xff)) {
			return(0);
		}
	}

	return(1);
}

static uint8_t verifySerial (const char *serialNumber) {

	int		a[3]	= {-1, -1, -1};

	if (sscanf(serialNumber, "%d-%d-%d", &a[0], &a[1], &a[2]) != 3) {
		return(0);
	}

	return(1);
}

static void get_address (char* msg, char* buf) {

	buf[15] = 0;
	do {
		printf("%s", msg);
		fflush(stdout);
		if ((scanf("%15s", buf) == 1) &&
			verifyIpAddress(buf)) {
			get_all();
			return;
		}
		get_all();
	} while (1);
}

static void get_string (char* msg, char** buf) {

	char tmp[128] = "";
	do {
		printf("%s", msg);
		fflush(stdout);
		if (scanf("%127s", tmp) == 1) {
			get_all();
			if (*buf)
				free(*buf);
			*buf = strdup(tmp);
			return;
		}
		get_all();
	} while (1);
}

static int searchDevices (beronet_device_t **allDevices, const char *sourceIpAddress, uint8_t *deviceCounter) {

	if (networkBroadcastMessage(sourceIpAddress, "find bero.*")) {
		return(-1);
	}

	networkReceiveReply(networkFoundDevice, allDevices, NULL, deviceCounter);

	return((*deviceCounter == 0) ? 0 : 1);
}

static void displayDeviceConfiguration (const beronet_device_t *currentDevice, const uint8_t displayAll) {

	if (currentDevice == NULL) {
		return;
	}

	printf("\nGeneral Information:\n\n");
	printf("\t%-20s %s\n", "Type",			((currentDevice->deviceType != NULL) ? currentDevice->deviceType : "Gateway"));
	printf("\t%-20s %s\n", "Serial",		((currentDevice->deviceSerial != NULL) ? currentDevice->deviceSerial : "unknown"));
	printf("\t%-20s %s\n", "Firmware-Version",	((currentDevice->deviceAppfs != NULL) ? currentDevice->deviceAppfs : "unknown"));
	printf("\t%-20s %s\n", "MAC-Address",		currentDevice->deviceMacAddress);
	printf("\nNetwork-Configuration:\n\n");
	printf("\t%-20s %s\n", "DHCP-Mode",		(currentDevice->configDhcpMode ? "on" : "off"));
	if (displayAll || !currentDevice->configDhcpMode) {
		printf("\t%-20s %s\n", "IP-Address",		(currentDevice->configIpAddress ? currentDevice->configIpAddress : "not set"));
		printf("\t%-20s %s\n", "Netmask",		(currentDevice->configNetmask ? currentDevice->configNetmask : "not set"));
		printf("\t%-20s %s\n", "Default Gateway",	(currentDevice->configGateway ? currentDevice->configGateway : "not set"));
		printf("\t%-20s %i\n", "MTU-Size",		(currentDevice->configMtuSize ? currentDevice->configMtuSize : 1500));
		printf("\t%-20s %s\n", "DNS-Server",		(currentDevice->configDnsServer ? currentDevice->configDnsServer : "not set"));
	}
}

static int changeDeviceConfiguration (const beronet_device_t *currentDevice, const char *sourceIpAddress) {

	uint8_t		configurationSaved		= 0;
	char		configurationCommand[512];

	if ((currentDevice == NULL) || !networkVerifyConfig(currentDevice)) {
		return(0);
	}

	memset(configurationCommand, 0x00, sizeof(configurationCommand));

	printf("\e[1;1H\e[2JSaving Settings to %s (%s):\n", currentDevice->deviceSerial, currentDevice->deviceMacAddress);
	displayDeviceConfiguration(currentDevice, 0);

	snprintf(configurationCommand, sizeof(configurationCommand), "set hw=%s;dhcp=%u;ip=%s;nm=%s;gw=%s%s%s;mtu=%u;",	currentDevice->deviceMacAddress,
															currentDevice->configDhcpMode,
															currentDevice->configIpAddress,
															currentDevice->configNetmask,
															currentDevice->configGateway,
															(currentDevice->configDnsServer ?
															";ns=" : ""),
															(currentDevice->configDnsServer ?
															currentDevice->configDnsServer : ""),
															currentDevice->configMtuSize);

	if (networkBroadcastMessage(sourceIpAddress, configurationCommand)) {
		printf("\nError sending save request!\n");
		return(0);
	}

	networkReceiveReply(networkSavedDeviceConfiguration, NULL, currentDevice, &configurationSaved);

	printf("\n%s\n", (configurationSaved ? "Configuration saved!" : "Failed saving configuration (it might be deactivated)!"));

	return(1);
}

static void changeDeviceConfigurationMenu (const uint8_t deviceIndex, beronet_device_t *allDevices, const char *sourceIpAddress) {

	beronet_device_t		*currentDevice		= NULL;
	uint8_t				next_try		= 1;
	uint16_t			mtu			= 0;

	if ((currentDevice = deviceFindByIndex(allDevices, deviceIndex)) == NULL) {
		return;
	}

	while (next_try == 1) {
		printf("\e[1;1H\e[2JChange Configuration of beroNet device %s\n", currentDevice->deviceSerial);

		displayDeviceConfiguration(currentDevice, 1);

		printf("\nActions:\n\n");
		if (currentDevice->configDhcpMode == 0) {
			printf(" d) Switch DHCP-Mode on\n");
			printf(" i) Change IP-Address\n");
			printf(" n) Change Netmask\n");
			printf(" g) Change Default Gateway\n");
			printf(" t) Change MTU-Size\n");
			printf(" m) Change DNS-Nameserver\n");
		} else {
			printf(" d) Switch DHCP-Mode off\n");
		}
		printf(" r) Reset Network-Configuration\n");
		printf(" s) Save and Quit\n");
		printf(" q) Quit\n\n");

		switch (get_char("What would you like to do? ", currentDevice->configDhcpMode ? "drsq" : "ingdtmrsq")) {
		case 'i':
			get_address("\nEnter IP-Address: ", currentDevice->configIpAddress);
			break;
		case 'n':
			get_address("\nEnter Netmask: ", currentDevice->configNetmask);
			break;
		case 'g':
			get_address("\nEnter Default Gateway: ", currentDevice->configGateway);
			break;
		case 't':
			while (1) {
				mtu = get_int("\nEnter MTU-Size: ");
				if (mtu >= 500 && mtu <= 1500) {
					currentDevice->configMtuSize = mtu;
					break;
				}
				printf("MTU-Size out-of-range!\n");
			}
			break;
		case 'd':
			currentDevice->configDhcpMode = !currentDevice->configDhcpMode;
			break;
		case 'm':
			printf("\n");
			get_string("Enter DNS-Server (type \"none\" to leave unconfigured): ", &(currentDevice->configDnsServer));
			if (currentDevice->configDnsServer && (strcmp(currentDevice->configDnsServer, "none") == 0)) {
				free(currentDevice->configDnsServer);
				currentDevice->configDnsServer = NULL;
			}
			break;
		case 'r':
			deviceSetDhcpMode(currentDevice, "1");
			deviceSetNewMtuSize(currentDevice, "1500");
			deviceSetNewIpAddress(currentDevice, "10.0.0.2");
			deviceSetNewNetmask(currentDevice, "255.0.0.0");
			deviceSetNewGateway(currentDevice, "10.0.0.1");
			deviceSetNewDnsServer(currentDevice, NULL);
			break;
		case 's':
			printf("\n");
			if (!changeDeviceConfiguration(currentDevice, sourceIpAddress)) {
				sleep(2);
				next_try = 1;
			}
		case 'q':
			return;
		}
	}
}

static uint8_t getNumberOrQuit (const char *inputPrompt, uint8_t *inputNumber) {

	char	inputString[4];

	printf("%s", inputPrompt);
	fflush(stdout);
	scanf("%4s", inputString);
	get_all();

	if (inputString[0] == 'q') {
		return(0);
	}

	*inputNumber = atoi(inputString);

	return(1);
}

static int displayDeviceSelectionMenu (beronet_device_t *allDevices, const char *sourceIpAddress) {

	uint8_t		deviceIndex		= 0;

	while (deviceIndex == 0) {
		if(!getNumberOrQuit("Please, select a device (enter 'q' to leave): ", &deviceIndex)) {
			return(sayGoodBye(EXIT_SUCCESS));
		}
	}

	changeDeviceConfigurationMenu(deviceIndex, allDevices, sourceIpAddress);
	return(sayGoodBye(EXIT_SUCCESS));
}

static void displayDeviceList (beronet_device_t *allDevices) {

	beronet_device_t	*currentDevice		= NULL;

	if (allDevices == NULL) {
		return;
	}

	currentDevice = deviceFindByIndex(allDevices, 1);
	do {
		printf(" %2u) serial: %18s \ttype: %-15s\tappfs: %-32s\tmac: %16s\tip: %-15s\n",	currentDevice->deviceIndex,
													((currentDevice->deviceSerial != NULL) ? currentDevice->deviceSerial : "unknown"),
													((currentDevice->deviceType != NULL) ? currentDevice->deviceType : "Gateway"),
													((currentDevice->deviceAppfs != NULL) ? currentDevice->deviceAppfs : "unknown"),
													currentDevice->deviceMacAddress,
													currentDevice->configIpAddress);
		currentDevice = currentDevice->nextDevice;
	} while (currentDevice != NULL);

	printf("\n");
}

static int changeDeviceConfigurationDirect (beronet_device_t *allDevices, const char *sourceIpAddress, const char *macAddress, const char *deviceSerial, const uint8_t displayFlag) {

	beronet_device_t	*currentDevice		= NULL;

	if ((currentDevice = deviceFindByUniqueIdentifier(allDevices, macAddress, deviceSerial)) == NULL) {
		return(sayGoodBye(EXIT_FAILURE));
	}

	if (displayFlag) {
		printf("\e[1;1H\e[2JDisplay Configuration of beroNet %s %s\n", ((currentDevice->deviceType != NULL) ? currentDevice->deviceType : "Gateway"), currentDevice->deviceSerial);
		displayDeviceConfiguration(currentDevice, 1);
		return(sayGoodBye(EXIT_SUCCESS));
	}

	changeDeviceConfigurationMenu(currentDevice->deviceIndex, allDevices, sourceIpAddress);
	return(sayGoodBye(EXIT_SUCCESS));
}

static int changeDeviceConfigurationCmdLine (beronet_device_t *allDevices, const char *sourceIpAddress, const char *macAddress, const char *deviceSerial, const char *dhcpMode,
							const char *ipAddress, const char *netMask, const char *gatewayAddress, const char *dnsAddress, const char *mtuSize, const uint8_t SaveConfig) {

	beronet_device_t	*currentDevice		= NULL;

	if ((currentDevice = deviceFindByUniqueIdentifier(allDevices, macAddress, deviceSerial)) == NULL) {
		return(sayGoodBye(EXIT_FAILURE));
	}

	if ((dhcpMode == NULL) || (strcmp(dhcpMode, "off") == 0)) {
		deviceSetDhcpMode(currentDevice, "0");

		if ((ipAddress != NULL) && (netMask != NULL) && (gatewayAddress != NULL)) {
			deviceSetNewIpAddress(currentDevice, ipAddress);
			deviceSetNewNetmask(currentDevice, netMask);
			deviceSetNewGateway(currentDevice, gatewayAddress);
		}

		if (dnsAddress != NULL) {
			deviceSetNewDnsServer(currentDevice, dnsAddress);
		}

		if (mtuSize != NULL) {
			deviceSetNewMtuSize(currentDevice, mtuSize);
		}
	} else if (strcmp(dhcpMode, "on") == 0) {
		deviceSetDhcpMode(currentDevice, "1");
		deviceSetNewIpAddress(currentDevice, "10.0.0.2");
		deviceSetNewNetmask(currentDevice, "255.0.0.0");
		deviceSetNewGateway(currentDevice, "10.0.0.1");
		deviceSetNewDnsServer(currentDevice, NULL);
		deviceSetNewMtuSize(currentDevice, "1500");
	}

	if (SaveConfig) {
		return(changeDeviceConfiguration(currentDevice, sourceIpAddress) ? sayGoodBye(EXIT_SUCCESS) : sayGoodBye(EXIT_FAILURE));
	}

	printf("\e[1;1H\e[2JSaving Settings to %s (%s):\n", currentDevice->deviceSerial, currentDevice->deviceMacAddress);
	displayDeviceConfiguration(currentDevice, 0);
	printf("\nAdd -s to your prior command to perform changes!\n");

	return(sayGoodBye(EXIT_SUCCESS));
}

int main (int argc, char **argv) {

	// arguments
	const struct option longopts[] = {
		{"mac-address",		1,	0,	'a'},
		{"serial",		1,	0,	'S'},
		{"bind-address",	1,	0,	'b'},
		{"dhcp-mode",		1,	0,	'd'},
		{"gw-address",		1,	0,	'g'},
		{"ip-address",		1,	0,	'i'},
		{"mtu-size",		1,	0,	'm'},
		{"netmask",		1,	0,	'n'},
		{"dns-server",		1,	0,	'z'},
		{"set-params",		0,	0,	's'},
		{"help",		0,	0,	'h'},
		{"display",		0,	0,	'D'},
		{0,			0,	0,	0}
	};

	beronet_device_t	*allDevices		= NULL;

	int			c			= 0,
				longind			= 0;

	char			*src_ip			= NULL,
				*card_mac		= NULL,
				*card_uuid		= NULL,
				*card_ip		= NULL,
				*card_nm		= NULL,
				*card_gw		= NULL,
				*card_dns		= NULL,
				*card_dhcp		= NULL,
				*card_mtu		= NULL;

	uint8_t			deviceCounter		= 0,
				flagSaveConfig		= 0,
				flagTypo		= 0,
				flagDisplayOnly		= 0;

	if (argc >= 2) {
		while ((c = getopt_long(argc, argv, "a:S:b:d:g:i:m:n:g:z:shD", longopts, &longind)) != -1) {
			switch (c) {
				case 'a':					// mac of bf to configure
					card_mac = strdup(optarg);
					if (!verifyMacAddress(card_mac)) {
						flagTypo = 1;
					}
					break;
				case 'S':					// serial of bf to configure
					if (!verifySerial((card_uuid = strdup(optarg)))) {
						flagTypo = 1;
					}
					break;
				case 'b':					// bind to address
					if (!verifyIpAddress((src_ip = strdup(optarg)))) {
						flagTypo = 1;
					}
					break;
				case 'd':					// dhcp [on|off]
					card_dhcp = strdup(optarg);
					if (strcmp("on", card_dhcp) && strcmp("off", card_dhcp)) {
						flagTypo = 1;
					}
					break;
				case 'g':					// gateway to set
					if (!verifyIpAddress((card_gw = strdup(optarg)))) {
						flagTypo = 1;
					}
					break;
				case 'i':					// ip-address to set
					if (!verifyIpAddress((card_ip = strdup(optarg)))) {
						flagTypo = 1;
					}
					break;
				case 'm':					// mtu-size
					card_mtu = strdup(optarg);
					if ((atoi(card_mtu) < 500) || (atoi(card_mtu) > 1500)) {
						flagTypo = 1;
					}
					break;
				case 'n':					// netmask to set
					if (!verifyIpAddress((card_nm = strdup(optarg)))) {
						flagTypo = 1;
					}
					break;
				case 'z':					// dns-server
					card_dns = strdup(optarg);
					if (!verifyIpAddress(card_dns) && strcmp("none", card_dns)) {
						flagTypo = 1;
					}
					break;
				case 's':					// save config
					flagSaveConfig = 1;
					break;
				case 'h':					// print help
					fprintf(stderr, "%s", usage_long);
					return(sayGoodBye(EXIT_SUCCESS));
				case 'D':
					flagDisplayOnly = 1;
					break;
				case '?':
					switch (optopt) {
						case 'a':
						case 'b':
						case 'd':
						case 'g':
						case 'i':
						case 'm':
						case 'n':
						case 'z':
							printf("%s", usage_short);
					}
					return(sayGoodBye(EXIT_FAILURE));
			}
		}
	}

	if (flagTypo) {
		printf("Do you see the typo?\n");
		return(sayGoodBye(EXIT_FAILURE));
	}

	if (src_ip == NULL) {
		src_ip = strdup("0.0.0.0");
	}

	// clear screen, display scanning message, search for devices
	printf("\e[1;1H\e[2JPlease wait, while we're scanning on %s for beroNet devices...\n\n", ((strcmp(src_ip, "0.0.0.0") != 0) ? src_ip : "all interfaces"));
	switch (searchDevices(&allDevices, src_ip, &deviceCounter)) {
	case -1:
		printf("Could not send request!\n");
		return(sayGoodBye(EXIT_FAILURE));
	case 0:
		printf("No beroNet devices found.\n");
		return(sayGoodBye(EXIT_SUCCESS));
	}

	// directly configure device with given values
	if ((card_mac || card_uuid) && (card_dhcp || (card_ip && card_nm && card_ip) || card_dns || card_mtu)) {
		return(changeDeviceConfigurationCmdLine(allDevices, src_ip, card_mac, card_uuid, card_dhcp, card_ip, card_nm, card_gw, card_dns, card_mtu, flagSaveConfig));
	}

	// card has been specified by MAC-Address (but nothing else), directly jump to it
	if (card_mac || card_uuid) {
		return(changeDeviceConfigurationDirect(allDevices, src_ip, card_mac, card_uuid, flagDisplayOnly));
	}

	// display device-list
	displayDeviceList(allDevices);

	// only display, we are leaving here
	if (flagDisplayOnly) {
		printf("Found %i beroNet devices.\n", deviceCounter);
		return(sayGoodBye(EXIT_SUCCESS));
	}

	// ask user to select device
	return(displayDeviceSelectionMenu(allDevices, src_ip));
}
