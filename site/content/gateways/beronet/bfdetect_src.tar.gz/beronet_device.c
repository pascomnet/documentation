/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: beronet_device.c
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "beronet_device.h"

void _deviceSetValue (char **deviceField, const char *newValue) {

	if (*deviceField) {
		free(*deviceField);
		*deviceField = NULL;
	}

	*deviceField = (newValue != NULL) ? strdup(newValue) : NULL;
}

void deviceSetSerial (beronet_device_t *currentDevice, const char *deviceSerial) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->deviceSerial), deviceSerial);
}

void deviceSetType (beronet_device_t *currentDevice, const char *deviceType) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->deviceType), deviceType);
}

void deviceSetAppfsVersion (beronet_device_t *currentDevice, const char *deviceAppfs) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->deviceAppfs), deviceAppfs);
}

void deviceSetMacAddress (beronet_device_t *currentDevice, const char *deviceMacAddress) {

	if ((currentDevice == NULL) || (deviceMacAddress == NULL)) {
		return;
	}

	_deviceSetValue(&(currentDevice->deviceMacAddress), deviceMacAddress);
}

void deviceSetNewIpAddress (beronet_device_t *currentDevice, const char *newIpAddress) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->configIpAddress), newIpAddress);
}

void deviceSetNewNetmask (beronet_device_t *currentDevice, const char *newNetmask) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->configNetmask), newNetmask);
}

void deviceSetNewGateway (beronet_device_t *currentDevice, const char *newGateway) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->configGateway), newGateway);
}

void deviceSetNewDnsServer (beronet_device_t *currentDevice, const char *newDnsServer) {

	if (currentDevice == NULL) {
		return;
	}

	_deviceSetValue(&(currentDevice->configDnsServer), newDnsServer);
}

void deviceSetNewMtuSize (beronet_device_t *currentDevice, const char *newMtuSize) {

	if (currentDevice == NULL) {
		return;
	}

	currentDevice->configMtuSize = atoi(newMtuSize);
}

void deviceSetDhcpMode (beronet_device_t *currentDevice, const char *dhcpMode) {

	if (currentDevice == NULL) {
		return;
	}

	currentDevice->configDhcpMode = (atoi(dhcpMode) ? 1 : 0);
}

beronet_device_t *deviceFindByIndex (beronet_device_t *allDevices, const uint8_t newIndex) {

	beronet_device_t	*currentDevice	= NULL;

	if (allDevices == NULL) {
		return(NULL);
	}

	if (newIndex == allDevices->deviceIndex) {
		return(allDevices);
	}

	if (newIndex < allDevices->deviceIndex) {
		currentDevice = allDevices->previousDevice;
		do {
			if (currentDevice->deviceIndex == newIndex) {
				return(currentDevice);
			}
			currentDevice = currentDevice->previousDevice;
		} while (currentDevice != NULL);
	}

	if (newIndex > allDevices->deviceIndex) {
		currentDevice = allDevices->nextDevice;
		do {
			currentDevice = currentDevice->nextDevice;
			if (currentDevice->deviceIndex == newIndex) {
				return(currentDevice);
			}
			currentDevice = currentDevice->nextDevice;
		} while (currentDevice != NULL);
	}

	return(NULL);
}

static beronet_device_t *_deviceFindByMac (beronet_device_t *allDevices, const char *macAddress) {

	beronet_device_t	*currentDevice		= NULL;

	if ((allDevices == NULL) || (macAddress == NULL)) {
		return(NULL);
	}

	currentDevice = deviceFindByIndex(allDevices, 1);
	do {
		if ((currentDevice->deviceMacAddress != NULL) && (strcmp(macAddress, currentDevice->deviceMacAddress) == 0)) {
			return(currentDevice);
		}

		currentDevice = currentDevice->nextDevice;
	} while (currentDevice != NULL);

	return(NULL);
}

static beronet_device_t *_deviceFindBySerial (beronet_device_t *allDevices, const char *deviceSerial) {

	beronet_device_t	*currentDevice		= NULL;

	if ((allDevices == NULL) || (deviceSerial == NULL)) {
		return(NULL);
	}

	currentDevice = deviceFindByIndex(allDevices, 1);
	do {
		if ((currentDevice->deviceSerial != NULL) && (strcmp(deviceSerial, currentDevice->deviceSerial) == 0)) {
			return(currentDevice);
		}

		currentDevice = currentDevice->nextDevice;
	} while (currentDevice != NULL);

	return(NULL);
}

beronet_device_t *deviceFindByUniqueIdentifier (beronet_device_t *allDevices, const char *macAddress, const char *deviceSerial) {

	beronet_device_t	*currentDevice		= NULL;

	if ((allDevices == NULL) && ((macAddress == NULL) || (deviceSerial == NULL))) {
		printf("Invalid parameters!\n\nYou'll need to specify the MAC-Address OR the Serial of a device!\n\n");
		return(NULL);
	}

	if (macAddress && deviceSerial) {
		printf("Invalid parameters!\n\nYou can only specify the MAC-Address OR the Serial of a device!\n\n");
		return(NULL);
	}

	if (macAddress) {
		if ((currentDevice = _deviceFindByMac(allDevices, macAddress)) == NULL) {
			printf("No beroNet device with MAC-Address %s found!\n", macAddress);
			return(NULL);
		}
		return(currentDevice);
	}

	if (deviceSerial) {
		if ((currentDevice = _deviceFindBySerial(allDevices, deviceSerial)) == NULL) {
			printf("No beroNet device with Serial %s found!\n", deviceSerial);
			return(NULL);
		}
		return(currentDevice);
	}

	return(NULL);
}

