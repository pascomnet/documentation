/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: beronet_usage.h
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */

#ifndef _BERONET_USAGE_H
#define _BERONET_USAGE_H 1

const char usage_short[] = "\nUsage:    bfdetect -b<ip_host> [-S<serial> | -a<mac_address>] -i<ip_card> -n<netmask> -g<gateway> -d<on|off> -m<mtu> -z<dns> -s]\n \
	  Enter 'bfdetect -h' to see more info on parameters!\n\n";

const char usage_long[] = "Usage:\n\n \
   bfdetect --bind-address <ip_host> [options to set parameters of card]\n\n \
      -b | --bind-address <ip_host>\n \
         Set the address to bind bfdetect to. This must be the address of an interface\n \
         installed to the computer bfdetect is executed on.\n\n \
   Set IP-Parameters of card:\n\n \
      -a | --mac-address <mac address of card>\n \
         MAC-address of the card to be configured\n\n \
      -S | --serial <serial>\n \
         Serial-Number of the card to be configured\n\n \
      -i | --ip-address <ip_card>\n \
	 IP-address that you want to assign to your beroNet device\n\n \
      -n | --nm-address <netmask>\n \
         Netmask that you want to assing to your beroNet device\n\n \
      -g | --gw-address <gateway>\n \
         IP-address of the gateway your beroNet device should use\n\n \
      -d | --dhcp-mode <on|off>\n \
         En- or disables dhcp-client of your beroNet device\n\n \
      -m | --mtu-size <500-1500>\n \
         Sets the MTU size of your beroNet device to a value between 500 and 1500\n\n \
      -z | --dns-server <nameserver|none>\n \
         Specifies the nameserver used by your beroNet device. Use 'none' to disable.\n\n \
      -s | --set-params\n \
         Really write the given settings to your beroNet device\n\n \
   Misc parameters:\n\n \
      -D | --display\n \
         Displays list of beroNet devices found in current network.\n \
	 This Parameter can be used in conjunction with --bind-address.\n\n \
   Example:\n\n \
      bfdetect -b192.168.0.128 -a00:00:00:aa:bb:cc -i192.168.120.2 -n255.255.255.0 -g192.168.120.1 -s\n\n \
      Will set the card with the given MAC-address to:\n \
         IP:      192.168.120.2\n \
	  Netmask: 255.255.255.0\n \
	  Gateway: 192.168.120.1\n\n \
      To set a card's IP-address the netmask and gateway have to be configured also.\n \
      The parameters ip-address, nm-address and gw-address have always to be used together.\n\n";

#endif /* _BERONET_USAGE_H */
