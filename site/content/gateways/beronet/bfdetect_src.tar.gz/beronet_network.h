/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: beronet_network.h
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */

#ifndef _BERONET_NETWORK_H
#define _BERONET_NETWORK_H 1

#include "beronet_device.h"

void networkReceiveReply (uint8_t (*callback) (const char *fromIpAddr, char *replyMessage, beronet_device_t **lastDevice, const beronet_device_t *currentDevice, uint8_t *miscVar),
														beronet_device_t **lastDevice, const beronet_device_t *currentDevice, uint8_t *miscVar);
int networkBroadcastMessage (const char *sourceIpAddress, char *broadcastMessage);

uint8_t networkSavedDeviceConfiguration (const char *fromIpAddress, char *replyMessage, beronet_device_t **allDevices, const beronet_device_t *currentDevice, uint8_t *saveSuccess);
uint8_t networkFoundDevice (const char *fromIpAddress, char *replyMessage, beronet_device_t **allDevices, const beronet_device_t *noDevice, uint8_t *deviceCounter);

uint8_t networkVerifyConfig (const beronet_device_t *currentDevice);

#endif /* _BERONET_NETWORK_H */
