/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: beronet_network.c
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ifaddrs.h>
#ifndef __CYGWIN__
# include <linux/if_link.h>
#endif
#include "beronet_device.h"

uint8_t networkSavedDeviceConfiguration (const char *fromIpAddressString, char *replyMessage, beronet_device_t **allDevices, const beronet_device_t *currentDevice, uint8_t *saveSuccess) {

	struct in_addr		fromIpAddress,
				deviceIpAddress;
	char			good_reply[32];

	if ((fromIpAddressString == NULL) || (replyMessage == NULL)) {
		return(0);
	}

	inet_aton(fromIpAddressString, &fromIpAddress);
	inet_aton(currentDevice->deviceIpAddress, &deviceIpAddress);

	if (deviceIpAddress.s_addr != fromIpAddress.s_addr) {
		return(0);
	}

	sprintf(good_reply, "ok hw=%s", currentDevice->deviceMacAddress);
	*saveSuccess = !strncmp(good_reply, replyMessage, strlen(good_reply));

	return(1);
}

uint8_t networkFoundDevice (const char *fromIpAddressString, char *replyMessage, beronet_device_t **allDevices, const beronet_device_t *noDevice, uint8_t *deviceCounter) {

	beronet_device_t	*currentDevice		= NULL,
				*lastDevice		= *allDevices;

	struct in_addr		fromIpAddress;

	char			*p			= NULL,
				*key			= NULL,
				*val			= NULL;

	if ((fromIpAddressString == NULL) || (replyMessage == NULL)) {
		return(0);
	}

	inet_aton(fromIpAddressString, &fromIpAddress);

	currentDevice = calloc(1, sizeof(beronet_device_t));
	memset(currentDevice, 0x00, sizeof(beronet_device_t));

	currentDevice->deviceIndex = ((lastDevice == NULL) ? 0 : lastDevice->deviceIndex) + 1;
	currentDevice->deviceIpAddress = strdup(fromIpAddressString);

	while ((p = strsep(&replyMessage, ";"))) {

		if ((key = strsep(&p, "=")) == NULL) {
			continue;
		}

		if ((val = strsep(&p, "\r\n")) == NULL) {
			continue;
		}

		if ((strlen(val)) == 0) {
			continue;
		}

		if (!strcmp(key, "hw")) {
			deviceSetMacAddress(currentDevice, val);
		} else if (!strcmp(key, "ip")) {
			deviceSetNewIpAddress(currentDevice, val);
		} else if (!strcmp(key, "nm")) {
			deviceSetNewNetmask(currentDevice, val);
		} else if (!strcmp(key, "mtu")) {
			deviceSetNewMtuSize(currentDevice, val);
		} else if (!strcmp(key, "gw")) {
			deviceSetNewGateway(currentDevice, val);
		} else if (!strcmp(key, "dhcp")) {
			deviceSetDhcpMode(currentDevice, val);
		} else if (!strcmp(key, "ns")) {
			deviceSetNewDnsServer(currentDevice, val);
		} else if (strcmp(key, "serial") == 0) {
			deviceSetSerial(currentDevice, val);
		} else if (strcmp(key, "type") == 0) {
			deviceSetType(currentDevice, val);
		} else if (strcmp(key, "appfs") == 0) {
			deviceSetAppfsVersion(currentDevice, val);
		}
	}

	currentDevice->configMtuSize = (currentDevice->configMtuSize == 0) ? 1500 : currentDevice->configMtuSize;

	currentDevice->previousDevice = lastDevice;
	if (lastDevice != NULL) {
		lastDevice->nextDevice = currentDevice;
	}

	*allDevices = currentDevice;
	*deviceCounter += 1;

	return(0);
}

void networkReceiveReply (uint8_t (*callback) (const char *fromIpAddrString, char *replyMessage, beronet_device_t **lastDevice, const beronet_device_t *currentDevice, uint8_t *miscVar),
														beronet_device_t **lastDevice, const beronet_device_t *currentDevice, uint8_t *miscVar) {

	struct sockaddr_in	sa_server,
				sa_client;

	socklen_t		sa_client_len		= sizeof(sa_client);
	int			s			= 0;
	char			reply[512];
	fd_set			fds;
	struct timeval		tv;

	if ((s = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		return;
	}

	memset(&sa_server, 0x00, sizeof(sa_server));
	sa_server.sin_family = AF_INET;
	sa_server.sin_addr.s_addr = htonl(INADDR_ANY);
	sa_server.sin_port = htons(65002);

	if (bind(s, (struct sockaddr *) &sa_server, sizeof(sa_server)) < 0) {
		return;
	}

	FD_ZERO(&fds);
	FD_SET(s, &fds);

	tv.tv_sec = 3;
	tv.tv_usec = 0;

	while (select(s + 1, &fds, 0, 0, &tv)) {
		memset(&reply, 0x00, sizeof(reply));
		if (recvfrom(s, reply, sizeof(reply) - 1, 0, (struct sockaddr *) &sa_client, &sa_client_len) < 0) {
			return;
		}

		if (callback(inet_ntoa(sa_client.sin_addr), reply, lastDevice, currentDevice, miscVar)) {
			break;
		}
	}

	close(s);
}

static int _networkBroadcastMessage (const char *sourceIpAddressString, char *broadcastMessage) {

	struct in_addr			sourceIpAddress;
	const struct in_addr		broadcastAddress		= { .s_addr = htonl(INADDR_BROADCAST) };
	struct sockaddr_in		sa_request,
					src;
	int				s		= 0,
					opt 		= 1,
					len 		= strlen(broadcastMessage);

	if ((sourceIpAddressString == NULL) || (broadcastMessage == NULL)) {
		return(-1);
	}


	inet_aton(sourceIpAddressString, &sourceIpAddress);

	if ((s = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		return(-1);
	}

	setsockopt(s, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));

	memset(&src, 0x00, sizeof(src));
	src.sin_family = AF_INET;
	src.sin_addr = sourceIpAddress;

	if (bind(s, (struct sockaddr *)&src, sizeof(src)) != 0) {
		return(-1);
	}

	memset(&sa_request, 0, sizeof(sa_request));
	sa_request.sin_family = AF_INET;
	sa_request.sin_addr = broadcastAddress;
	sa_request.sin_port = htons(65001);

	if (sendto(s, broadcastMessage, len, 0, (struct sockaddr *)&sa_request, sizeof(sa_request)) != len) {
		return(-1);
	}

	close(s);
	s = 0;

	return(0);
}

int networkBroadcastMessage (const char *sourceIpAddressString, char *broadcastMessage) {

	struct ifaddrs		*ifaddr		= NULL,
				*ifa		= NULL;
	int			i		= 0,
				ret		= 0;
	char			host[24];

	if ((sourceIpAddressString == NULL) || (broadcastMessage == NULL)) {
		return(-1);
	}

	if (strcmp(sourceIpAddressString, "0.0.0.0") != 0) {
		return(_networkBroadcastMessage(sourceIpAddressString, broadcastMessage));
	}

	if (getifaddrs(&ifaddr) == -1) {
		return(0);
	}

	for (ifa = ifaddr, i = 0; ifa != NULL; ifa = ifa->ifa_next, i++) {
		if ((ifa->ifa_addr == NULL) || (ifa->ifa_addr->sa_family != AF_INET)) {
			continue;
		}

		getnameinfo(ifa->ifa_addr, sizeof(struct sockaddr_in), host, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);
		if (strcmp(host, "127.0.0.1") == 0) {
			continue;
		}

		if (_networkBroadcastMessage(host, broadcastMessage) == 1) {
			ret = 1;
		}
	}

	return(ret);
}

uint8_t networkVerifyConfig (const beronet_device_t *currentDevice) {

	struct in_addr		deviceIpAddress,
				deviceNetmask,
				deviceGateway;

	if (currentDevice == NULL) {
		printf("%s failed! Invalid Device!\n\n", __FUNCTION__);
		return(0);
	}

	if (!inet_aton(currentDevice->configIpAddress, &deviceIpAddress)) {
		printf("%s failed! Invalid IP-Address!\n\n", __FUNCTION__);
		return(0);
	}

	if (!inet_aton(currentDevice->configNetmask, &deviceNetmask)) {
		printf("%s failed! Invalid Netmask!\n\n", __FUNCTION__);
		return(0);
	}

	if (!inet_aton(currentDevice->configGateway, &deviceGateway)) {
		printf("%s failed! Invalid Default Gateway!\n\n", __FUNCTION__);
		return(0);
	}

	if ((deviceIpAddress.s_addr & deviceNetmask.s_addr) != (deviceGateway.s_addr & deviceNetmask.s_addr)) {
		printf("%s failed! IP-Address and Gateway are not part of the same network!\n\n", __FUNCTION__);
		return(0);
	}

	return(1);
}

