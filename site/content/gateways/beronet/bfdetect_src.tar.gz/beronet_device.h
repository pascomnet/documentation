/*
 * bfdetect: Tool to detect and configure beroNet devices.
 * File: beronet_device.h
 * Version: 3.0
 * Copyright: (C) 2015 beroNet GmbH
 * Authors: Florian Kraatz <fk@beronet.com>
 *
 * For help and support, please contact: support@beronet.com
 */

#ifndef _BERONET_DEVICE_H
#define _BERONET_DEVICE_H 1

#include <stdint.h>

/* typedefinitions */
typedef struct _beronet_device_t {
	uint8_t				deviceIndex;
	char				*deviceType;
	char				*deviceMacAddress;
	char				*deviceSerial;
	char				*deviceAppfs;
	char				*deviceIpAddress;	// this is the IP-Address to be communicated with

	uint8_t				configDhcpMode;
	uint16_t			configMtuSize;
	char				*configIpAddress;	// this is the IP-Address to be configured
	char				*configNetmask;
	char				*configGateway;
	char				*configDnsServer;

	struct _beronet_device_t	*previousDevice;
	struct _beronet_device_t	*nextDevice;
} beronet_device_t;


/* function declarations */

void deviceSetSerial (beronet_device_t *currentDevice, const char *deviceSerial);
void deviceSetType (beronet_device_t *currentDevice, const char *deviceType);
void deviceSetAppfsVersion (beronet_device_t *currentDevice, const char *deviceAppfs);
void deviceSetMacAddress (beronet_device_t *currentDevice, const char *deviceMacAddress);

void deviceSetDhcpMode (beronet_device_t *currentDevice, const char *dhcpMode);
void deviceSetNewIpAddress (beronet_device_t *currentDevice, const char *newIpAddress);
void deviceSetNewNetmask (beronet_device_t *currentDevice, const char *newNetmask);
void deviceSetNewGateway (beronet_device_t *currentDevice, const char *newGateway);
void deviceSetNewDnsServer (beronet_device_t *currentDevice, const char *newDnsServer);
void deviceSetNewMtuSize (beronet_device_t *currentDevice, const char *newMtuSize);

beronet_device_t *deviceFindByIndex (beronet_device_t *allDevices, const uint8_t index);
beronet_device_t *deviceFindByUniqueIdentifier (beronet_device_t *allDevices, const char *macAddress, const char *deviceSerial);

#endif /*_BERONET_DEVICE_H */
